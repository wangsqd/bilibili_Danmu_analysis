## dm_protobuf 为 SocialSisterYi 下 Github 库 bilibili-API-collect 的引用

> ## 引用文件为 [dm.proto](https://github.com/SocialSisterYi/bilibili-API-collect/blob/master/grpc_api/bilibili/community/service/dm/v1/dm.proto)